#include <GL/glew.h>
#include "common.hh"
#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <numbers>
#include <vector>

using namespace glm;

class SwirlSphere {
private:
    uint32_t progid, vao, vbo;
    uint32_t resolution;
public:
    uint32_t getProgID() const { return progid; }
    SwirlSphere(double r, uint32_t latRes, uint32_t lonRes) {
        resolution = (latRes - 1) * lonRes + 2; //
        progid = loadShaders("swirl.vert", "swirl.frag");
        std::vector<float> vert;
        vert.reserve(resolution * 3); //

        double dlon = 2.0 * std::numbers::pi / lonRes; //
        double dlat = std::numbers::pi / latRes; //

        // Strict Spherical Logic to prevent "drop" distortion
        for (uint32_t j = 1; j < latRes; ++j) {
            double lat = -std::numbers::pi / 2.0 + j * dlat; 
            double rcircle = r * cos(lat); 
            double z = r * sin(lat); 
            for (uint32_t i = 0; i < lonRes; ++i) {
                double lon = i * dlon;
                vert.push_back(float(rcircle * cos(lon)));
                vert.push_back(float(rcircle * sin(lon)));
                vert.push_back(float(z));
            }
        }
        vert.insert(vert.end(), {0.0f, 0.0f, float(-r)}); // South Pole
        vert.insert(vert.end(), {0.0f, 0.0f, float(r)});  // North Pole

        glGenVertexArrays(1, &vao);
        glBindVertexArray(vao);
        glGenBuffers(1, &vbo);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, vert.size() * sizeof(float), vert.data(), GL_STATIC_DRAW);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(0);
    }
    void render(mat4& trans) {
        glUseProgram(progid);
        glUniformMatrix4fv(glGetUniformLocation(progid, "trans"), 1, GL_FALSE, &trans[0][0]);
        glUniform1f(glGetUniformLocation(progid, "time"), (float)glfwGetTime());
        glBindVertexArray(vao);
        glEnable(GL_PROGRAM_POINT_SIZE); 
        glDrawArrays(GL_POINTS, 0, resolution); 
    }
    ~SwirlSphere() {
        glDeleteBuffers(1, &vbo);
        glDeleteVertexArrays(1, &vao);
        glDeleteProgram(progid);
    }
};

void glmain() {
    win = createWindow(800, 800, "Step-by-Step Dense Sphere");
    glClearColor(0.0f, 0.0f, 0.05f, 1.0f);
    glEnable(GL_DEPTH_TEST);

    uint32_t latRes = 30, lonRes = 60; // Start with a clear grid
    SwirlSphere* sphere = new SwirlSphere(1.0, latRes, lonRes);
    int frameCount = 0;

    do {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        float t = (float)glfwGetTime();

        // Incrementally increase density to keep it structured
        if (++frameCount % 150 == 0 && latRes < 400) {
            delete sphere;
            latRes += 20; lonRes += 40;
            sphere = new SwirlSphere(1.0, latRes, lonRes);
        }

        // Perspective and Aspect Ratio (Prevents the "Drop" look)
        mat4 proj = perspective(radians(45.0f), 1.0f, 0.1f, 100.0f);
        mat4 view = lookAt(vec3(4.0 * cos(t * 0.1), 1.0, 4.0 * sin(t * 0.1)), vec3(0), vec3(0, 1, 0));
        mat4 trans = proj * view;

        glUseProgram(sphere->getProgID());
        glUniform1f(glGetUniformLocation(sphere->getProgID(), "complexity"), (float)latRes / 400.0f);
        
        sphere->render(trans);
        glfwSwapBuffers(win);
        glfwPollEvents();
    } while (glfwGetKey(win, GLFW_KEY_ESCAPE) != GLFW_PRESS && glfwWindowShouldClose(win) == 0);
    delete sphere;
}