#version 330 core
layout (location = 0) in vec3 aPos;
uniform mat4 trans;
uniform float complexity;
out vec3 vPos;

void main() {
    vPos = aPos;
    gl_Position = trans * vec4(aPos, 1.0);
    // Point size gets smaller as the sphere gets denser
    gl_PointSize = mix(5.0, 1.5, complexity); 
}