#version 330 core
in vec3 vPos;
out vec4 FragColor;
uniform float time, complexity;

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

void main() {
    float theta = atan(vPos.y, vPos.x);
    float phi = acos(vPos.z / length(vPos));

    // Keep the Grid Structured
    float gridFreq = 15.0 + (complexity * 25.0); 
    float latGrid = sin(phi * gridFreq);
    float lonGrid = sin(theta * gridFreq);
    float frameMask = smoothstep(0.0, 0.15, abs(latGrid)) * smoothstep(0.0, 0.15, abs(lonGrid));

    // Color Swirls evolve from subtle to neon
    float r = 0.5 + 0.5 * sin(vPos.x * (10.0 * complexity) + time);
    float g = 0.5 + 0.5 * sin(vPos.y * (15.0 * complexity) + time * 1.2);
    float b = 0.5 + 0.5 * sin(vPos.z * (20.0 * complexity) + time * 1.5);
    
    // Extra color layers added at higher density
    float glow = step(0.5, complexity) * abs(sin(time * 2.5 + vPos.y * 5.0));
    vec3 color = vec3(r + glow, g, b + glow * 0.5);

    // Randomized sequential reveal
    vec2 windowID = floor(vec2(theta, phi) * (gridFreq / 3.14159));
    float reveal = smoothstep(hash(windowID) * 10.0, hash(windowID) * 10.0 + 2.0, time);

    FragColor = vec4(color * frameMask * reveal, 1.0);
}