// ==========================================
// Julie Kumar - Graphics - HW #2
// I consulted with Gemini 3 Pro regarding astronomy and physics as I do not have much background in space sciences
// I used this image for moon: https://upload.wikimedia.org/wikipedia/commons/d/d1/Solarsystemscope_texture_8k_moon.jpg
// stars were added for light (otherwise it is too dark in the space)
// it takes several minutes to start because of the images
// minor 'manipulation' of the animation was added
// ==========================================

// TEXTURES
PShape sun, mercury, venus, earth, moon;
PImage sunTex, mercuryTex, venusTex, earthTex, moonTex;

// TEXTURE FLAGS
boolean sunReady = false;
boolean mercReady = false;
boolean venusReady = false;
boolean earthReady = false;
boolean moonReady = false;

// STARFIELD (Simple Array for Speed)
int starCount = 1000;
float[] starX = new float[starCount];
float[] starY = new float[starCount];
float[] starZ = new float[starCount];

// PHYSICS CONSTANTS
final float SUN_W           = TWO_PI / 25.38;
final float MERCURY_ORBIT_W = TWO_PI / 87.97;
final float MERCURY_ROT_W   = TWO_PI / 58.65;
final float VENUS_ORBIT_W   = TWO_PI / 224.70;
final float VENUS_ROT_W     = TWO_PI / 243.02; 
final float EARTH_ORBIT_W   = TWO_PI / 365.26;
final float EARTH_ROT_W     = TWO_PI / 0.997;
final float MOON_ORBIT_W    = TWO_PI / 27.32;

// ORBITAL ELEMENTS
final float MERCURY_INC = radians(7.0);
final float MERCURY_ECC = 0.2056;
final float MERCURY_A   = 130; 

final float VENUS_INC   = radians(3.39);
final float VENUS_ECC   = 0.0068; 
final float VENUS_A     = 220;

final float EARTH_ECC   = 0.0167;
final float EARTH_A     = 400;

final float MOON_INCLINATION = radians(5.145);
final float MOON_NODE        = radians(125.08);

// STATE
float sunRot = 0;
float mercuryRot = 0, mercuryOrbit = 0;
float venusRot = 0,   venusOrbit = 0;
float earthRot = 0,   earthOrbit = 0;
float moonOrbit = 0;

// CAMERA & CONTROL
int lastTime; 
float daysPerSecond = 2.0; 
int speedState = 1; 

// ZOOM SPECIAL EFFECT VARIABLES
float camZ = -450;        // Current Camera Position
float targetCamZ = -450;  // Where the camera wants to go
boolean isZoomedIn = false;

void setup() {
  size(1000, 1000, P3D);
  noStroke();
  
  // 1. INSTANT LOAD
  sunTex     = loadImage("sun.jpg"); 
  mercuryTex = loadImage("Solarsystemscope_texture_8k_mercury.jpg");
  venusTex   = loadImage("Solarsystemscope_texture_8k_venus_surface.jpg");
  earthTex   = loadImage("earthmap1k.jpg"); 
  moonTex = loadImage("Solarsystemscope_texture_8k_moon.jpg");
  // 2. CREATE PLANETS
  sun = createShape(SPHERE, 80);
  sun.setEmissive(255); 
  
  mercury = createShape(SPHERE, 15);
  mercury.setEmissive(0); mercury.setSpecular(0);
  
  venus = createShape(SPHERE, 38);
  venus.setEmissive(0); venus.setSpecular(0); 
  
  earth = createShape(SPHERE, 40);
  earth.setEmissive(0); earth.setSpecular(255); earth.setShininess(20); 
  
  moon = createShape(SPHERE, 10);
  moon.setEmissive(0); moon.setSpecular(0);    
  
  // 3. GENERATE STARS
  for(int i=0; i<starCount; i++) {
    starX[i] = random(-2500, 2500);
    starY[i] = random(-2500, 2500);
    starZ[i] = random(-3000, -1000); 
  }
  
  lastTime = millis();
}

void draw() {
  background(10, 10, 15); 
  
  // --- TEXTURES ---
  if (!sunReady && sunTex.width > 0) { sun.setTexture(sunTex); sunReady = true; }
  if (!mercReady && mercuryTex.width > 0) { mercury.setTexture(mercuryTex); mercReady = true; }
  if (!venusReady && venusTex.width > 0) { venus.setTexture(venusTex); venusReady = true; }
  if (!earthReady && earthTex.width > 0) { earth.setTexture(earthTex); earthReady = true; }
  if (!moonReady && moonTex.width > 0) { moon.setTexture(moonTex); moonReady = true; }

  // --- TIME STEP ---
  int now = millis();
  float dtSeconds = (now - lastTime) / 1000.0;
  lastTime = now;
  if (dtSeconds > 0.1) dtSeconds = 0.1; 
  float dtDays = (speedState == 0) ? 0 : daysPerSecond * dtSeconds;
  dtDays = min(dtDays, 2.0); 

  // --- CAMERA ZOOM EFFECT (The "Lerp") ---
  // Smoothly move current Z towards target Z (5% per frame)
  camZ = lerp(camZ, targetCamZ, 0.05);
  
  translate(width/2, height/2, camZ); 
  scale(1, -1, 1);

  // --- DRAW STARS ---
  hint(DISABLE_DEPTH_TEST); 
  pushStyle();
  noLights(); 
  stroke(255); 
  strokeWeight(3); 
  beginShape(POINTS);
  for(int i=0; i<starCount; i++) {
    vertex(starX[i], starY[i], starZ[i]);
  }
  endShape();
  popStyle();
  hint(ENABLE_DEPTH_TEST);

  // --- LIGHTING ---
  lights(); 
  ambientLight(80, 80, 90); 
  directionalLight(50, 50, 70, -0.5, 0.5, -1);
  pointLight(255, 255, 255, 0, 0, 0);
  lightSpecular(255, 255, 255);

  // --- SUN ---
  pushMatrix();
  rotateY(sunRot);
  shape(sun);
  popMatrix();

  // --- MERCURY ---
  pushMatrix();
  rotateZ(MERCURY_INC); 
  rotateY(mercuryOrbit);
  float rMerc = MERCURY_A * (1 - MERCURY_ECC*MERCURY_ECC) / (1 + MERCURY_ECC * cos(mercuryOrbit));
  translate(rMerc, 0, 0); 
  rotateY(-mercuryOrbit); 
  rotateY(mercuryRot);
  shape(mercury);
  popMatrix();

  // --- VENUS ---
  pushMatrix();
  rotateZ(VENUS_INC); 
  rotateY(venusOrbit);
  translate(VENUS_A, 0, 0); 
  rotateY(-venusOrbit); 
  rotateZ(radians(177.3)); 
  rotateY(venusRot);
  shape(venus);
  popMatrix();

  // --- EARTH SYSTEM ---
  pushMatrix();
  rotateY(earthOrbit);
  float rEarth = EARTH_A * (1 - EARTH_ECC*EARTH_ECC) / (1 + EARTH_ECC * cos(earthOrbit));
  translate(rEarth, 0, 0); 
  rotateY(-earthOrbit); 
  
  // MOON
  pushMatrix();
  rotateY(MOON_NODE);        
  rotateZ(MOON_INCLINATION); 
  rotateY(moonOrbit);
  translate(100, 0, 0); 
  rotateY(-moonOrbit);
  rotateY(PI); 
  shape(moon);
  popMatrix();

  // EARTH SPIN
  pushMatrix();
  rotateZ(radians(23.44)); 
  rotateY(earthRot);       
  shape(earth);
  popMatrix();
  
  popMatrix(); 

  // --- PHYSICS ---
  sunRot       = (sunRot       + dtDays * SUN_W)         % TWO_PI;
  mercuryOrbit = (mercuryOrbit + dtDays * MERCURY_ORBIT_W) % TWO_PI;
  mercuryRot   = (mercuryRot   + dtDays * MERCURY_ROT_W)   % TWO_PI;
  venusOrbit   = (venusOrbit   + dtDays * VENUS_ORBIT_W)   % TWO_PI;
  venusRot     = (venusRot     + dtDays * VENUS_ROT_W)     % TWO_PI;
  earthOrbit   = (earthOrbit   + dtDays * EARTH_ORBIT_W)   % TWO_PI;
  earthRot     = (earthRot     + dtDays * EARTH_ROT_W)     % TWO_PI;
  moonOrbit    = (moonOrbit    + dtDays * MOON_ORBIT_W)    % TWO_PI;

  // --- HUD ---
  hint(DISABLE_DEPTH_TEST);
  camera(); 
  noLights();
  fill(255);
  textSize(16);
  
  String status = "Paused";
  if (speedState == 1) status = "Real-time x" + int(daysPerSecond);
  if (speedState == 2) status = "Fast Forward x" + int(daysPerSecond);
  text("Left Click: Speed (" + status + ")", 20, 30);
  
  String zoomStatus = isZoomedIn ? "SUN VIEW" : "SYSTEM VIEW";
  text("Right Click: Zoom (" + zoomStatus + ")", 20, 50);
  
  hint(ENABLE_DEPTH_TEST);
}

void mousePressed() {
   // LEFT CLICK: Change Speed
   if (mouseButton == LEFT) {
     speedState++;
     if (speedState > 2) speedState = 0;
     if (speedState == 1) daysPerSecond = 2.0;
     if (speedState == 2) daysPerSecond = 20.0;
   }
   
   // RIGHT CLICK: Toggle Zoom Effect
   if (mouseButton == RIGHT) {
     isZoomedIn = !isZoomedIn;
     if (isZoomedIn) {
       targetCamZ = -180; // Close to the Sun (Radius 80 + Space)
     } else {
       targetCamZ = -450; // Far view
     }
   }
}
