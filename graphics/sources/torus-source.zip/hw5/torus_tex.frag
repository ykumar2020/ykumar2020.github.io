#version 330 core
in vec2 vUV;
in float vLight;

uniform sampler2D tex;

out vec4 FragColor;

void main() {
    vec4 base = texture(tex, vUV);
    FragColor = vec4(base.rgb * vLight, base.a);
}
