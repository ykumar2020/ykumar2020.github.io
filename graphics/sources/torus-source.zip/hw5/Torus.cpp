#include "Torus.hpp"

#include <cmath>

namespace {
constexpr float PI = 3.14159265358979323846f;

inline VertexRGB makeRGBVertex(float u, float v, float R, float r) {
    const float cu = std::cos(u);
    const float su = std::sin(u);
    const float cv = std::cos(v);
    const float sv = std::sin(v);

    VertexRGB out{};
    out.x = (R + r * cv) * cu;
    out.y = (R + r * cv) * su;
    out.z = r * sv;

    // Smooth, periodic color palette tied to torus parameters.
    out.r = 0.55f + 0.45f * std::cos(u);
    out.g = 0.55f + 0.45f * std::cos(v + 2.0943951f);     // +120 degrees
    out.b = 0.55f + 0.45f * std::cos(u + v + 4.1887902f); // +240 degrees
    return out;
}

inline VertexTex makeTexVertex(float u, float v, float R, float r, float uu, float vv) {
    const float cu = std::cos(u);
    const float su = std::sin(u);
    const float cv = std::cos(v);
    const float sv = std::sin(v);

    VertexTex out{};
    out.x = (R + r * cv) * cu;
    out.y = (R + r * cv) * su;
    out.z = r * sv;
    out.u = uu;
    out.v = vv;
    return out;
}

void buildIndexedTriangles(uint32_t radialRes, uint32_t tubularRes, std::vector<uint32_t>& indices) {
    indices.clear();
    indices.reserve(static_cast<std::size_t>(radialRes) * tubularRes * 6u);

    const uint32_t row = tubularRes + 1u;
    for (uint32_t i = 0; i < radialRes; ++i) {
        for (uint32_t j = 0; j < tubularRes; ++j) {
            const uint32_t a = i * row + j;
            const uint32_t b = (i + 1u) * row + j;
            const uint32_t c = a + 1u;
            const uint32_t d = b + 1u;

            indices.push_back(a);
            indices.push_back(b);
            indices.push_back(c);

            indices.push_back(c);
            indices.push_back(b);
            indices.push_back(d);
        }
    }
}
} // namespace

void Torus::generateIndexedRGB(uint32_t radialRes, uint32_t tubularRes, float majorRadius, float minorRadius,
                               std::vector<VertexRGB>& vertices, std::vector<uint32_t>& indices) {
    vertices.clear();
    vertices.reserve(static_cast<std::size_t>(radialRes + 1u) * static_cast<std::size_t>(tubularRes + 1u));

    for (uint32_t i = 0; i <= radialRes; ++i) {
        const float uu = static_cast<float>(i) / static_cast<float>(radialRes);
        const float u = uu * 2.0f * PI;
        for (uint32_t j = 0; j <= tubularRes; ++j) {
            const float vv = static_cast<float>(j) / static_cast<float>(tubularRes);
            const float v = vv * 2.0f * PI;
            vertices.push_back(makeRGBVertex(u, v, majorRadius, minorRadius));
        }
    }

    buildIndexedTriangles(radialRes, tubularRes, indices);
}

void Torus::generateNonIndexedRGB(uint32_t radialRes, uint32_t tubularRes, float majorRadius, float minorRadius,
                                  std::vector<VertexRGB>& vertices) {
    vertices.clear();
    vertices.reserve(static_cast<std::size_t>(radialRes) * tubularRes * 6u);

    for (uint32_t i = 0; i < radialRes; ++i) {
        const float uu0 = static_cast<float>(i) / static_cast<float>(radialRes);
        const float uu1 = static_cast<float>(i + 1u) / static_cast<float>(radialRes);
        const float u0 = uu0 * 2.0f * PI;
        const float u1 = uu1 * 2.0f * PI;

        for (uint32_t j = 0; j < tubularRes; ++j) {
            const float vv0 = static_cast<float>(j) / static_cast<float>(tubularRes);
            const float vv1 = static_cast<float>(j + 1u) / static_cast<float>(tubularRes);
            const float v0 = vv0 * 2.0f * PI;
            const float v1 = vv1 * 2.0f * PI;

            const VertexRGB a = makeRGBVertex(u0, v0, majorRadius, minorRadius);
            const VertexRGB b = makeRGBVertex(u1, v0, majorRadius, minorRadius);
            const VertexRGB c = makeRGBVertex(u0, v1, majorRadius, minorRadius);
            const VertexRGB d = makeRGBVertex(u1, v1, majorRadius, minorRadius);

            vertices.push_back(a);
            vertices.push_back(b);
            vertices.push_back(c);

            vertices.push_back(c);
            vertices.push_back(b);
            vertices.push_back(d);
        }
    }
}

void Torus::generateIndexedTextured(uint32_t radialRes, uint32_t tubularRes, float majorRadius, float minorRadius,
                                    std::vector<VertexTex>& vertices, std::vector<uint32_t>& indices) {
    vertices.clear();
    vertices.reserve(static_cast<std::size_t>(radialRes + 1u) * static_cast<std::size_t>(tubularRes + 1u));

    for (uint32_t i = 0; i <= radialRes; ++i) {
        const float uu = static_cast<float>(i) / static_cast<float>(radialRes);
        const float u = uu * 2.0f * PI;
        for (uint32_t j = 0; j <= tubularRes; ++j) {
            const float vv = static_cast<float>(j) / static_cast<float>(tubularRes);
            const float v = vv * 2.0f * PI;
            vertices.push_back(makeTexVertex(u, v, majorRadius, minorRadius, uu, vv));
        }
    }

    buildIndexedTriangles(radialRes, tubularRes, indices);
}
