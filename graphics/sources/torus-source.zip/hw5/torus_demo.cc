#include "common/common.hh"
#include "Torus.hpp"

#include <iostream>
#include <string>

namespace {
constexpr uint32_t RADIAL_RES = 64;
constexpr uint32_t TUBULAR_RES = 40;
constexpr float MAJOR_RADIUS = 0.72f;
constexpr float MINOR_RADIUS = 0.24f;

enum class RenderMode {
    Wireframe = 1,
    GouraudNonIndexed = 2,
    GouraudIndexed = 3,
    TexturedIndexed = 4
};

struct MeshGL {
    GLuint vao = 0;
    GLuint vbo = 0;
    GLuint ebo = 0;
    GLsizei count = 0;
    bool indexed = false;

    void destroy() {
        if (ebo) glDeleteBuffers(1, &ebo);
        if (vbo) glDeleteBuffers(1, &vbo);
        if (vao) glDeleteVertexArrays(1, &vao);
        vao = vbo = ebo = 0;
        count = 0;
        indexed = false;
    }
};

MeshGL uploadRGBMeshIndexed(const std::vector<VertexRGB>& vertices, const std::vector<uint32_t>& indices) {
    MeshGL mesh{};
    mesh.indexed = true;
    mesh.count = static_cast<GLsizei>(indices.size());

    glGenVertexArrays(1, &mesh.vao);
    glGenBuffers(1, &mesh.vbo);
    glGenBuffers(1, &mesh.ebo);

    glBindVertexArray(mesh.vao);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(vertices.size() * sizeof(VertexRGB)), vertices.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, static_cast<GLsizeiptr>(indices.size() * sizeof(uint32_t)), indices.data(), GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexRGB), reinterpret_cast<void*>(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexRGB), reinterpret_cast<void*>(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
    return mesh;
}

MeshGL uploadRGBMeshNonIndexed(const std::vector<VertexRGB>& vertices) {
    MeshGL mesh{};
    mesh.indexed = false;
    mesh.count = static_cast<GLsizei>(vertices.size());

    glGenVertexArrays(1, &mesh.vao);
    glGenBuffers(1, &mesh.vbo);

    glBindVertexArray(mesh.vao);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(vertices.size() * sizeof(VertexRGB)), vertices.data(), GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexRGB), reinterpret_cast<void*>(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexRGB), reinterpret_cast<void*>(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
    return mesh;
}

MeshGL uploadTexturedMeshIndexed(const std::vector<VertexTex>& vertices, const std::vector<uint32_t>& indices) {
    MeshGL mesh{};
    mesh.indexed = true;
    mesh.count = static_cast<GLsizei>(indices.size());

    glGenVertexArrays(1, &mesh.vao);
    glGenBuffers(1, &mesh.vbo);
    glGenBuffers(1, &mesh.ebo);

    glBindVertexArray(mesh.vao);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(vertices.size() * sizeof(VertexTex)), vertices.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, static_cast<GLsizeiptr>(indices.size() * sizeof(uint32_t)), indices.data(), GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexTex), reinterpret_cast<void*>(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexTex), reinterpret_cast<void*>(3 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindVertexArray(0);
    return mesh;
}

void drawMesh(const MeshGL& mesh) {
    glBindVertexArray(mesh.vao);
    if (mesh.indexed) {
        glDrawElements(GL_TRIANGLES, mesh.count, GL_UNSIGNED_INT, nullptr);
    } else {
        glDrawArrays(GL_TRIANGLES, 0, mesh.count);
    }
}

void setCommonUniforms(GLuint program, const glm::mat4& model, const glm::mat4& viewProj) {
    const glm::mat3 normalMatrix = glm::transpose(glm::inverse(glm::mat3(model)));
    const glm::vec3 lightDirWorld = glm::normalize(glm::vec3(-0.6f, 0.85f, 0.5f));

    glUniformMatrix4fv(glGetUniformLocation(program, "uModel"), 1, GL_FALSE, &model[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(program, "uViewProj"), 1, GL_FALSE, &viewProj[0][0]);
    glUniformMatrix3fv(glGetUniformLocation(program, "uNormalMatrix"), 1, GL_FALSE, &normalMatrix[0][0]);
    glUniform1f(glGetUniformLocation(program, "uMajorRadius"), MAJOR_RADIUS);
    glUniform3fv(glGetUniformLocation(program, "uLightDirWorld"), 1, &lightDirWorld[0]);
}

std::string modeName(RenderMode mode) {
    switch (mode) {
        case RenderMode::Wireframe: return "1 Wireframe";
        case RenderMode::GouraudNonIndexed: return "2 Gouraud xyzrgb non-indexed";
        case RenderMode::GouraudIndexed: return "3 Gouraud xyzrgb indexed";
        case RenderMode::TexturedIndexed: return "4 Textured xyuv indexed";
    }
    return "Unknown";
}
} // namespace

void glmain() {
    win = createWindow(1280, 840, "Torus Demo");

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    const GLuint gouraudProg = loadShaders("torus_gouraud.vert", "torus_gouraud.frag");
    const GLuint textureProg = loadShaders("torus_tex.vert", "torus_tex.frag");

    std::vector<VertexRGB> rgbIndexedVerts;
    std::vector<uint32_t> rgbIndices;
    Torus::generateIndexedRGB(RADIAL_RES, TUBULAR_RES, MAJOR_RADIUS, MINOR_RADIUS, rgbIndexedVerts, rgbIndices);

    std::vector<VertexRGB> rgbNonIndexedVerts;
    Torus::generateNonIndexedRGB(RADIAL_RES, TUBULAR_RES, MAJOR_RADIUS, MINOR_RADIUS, rgbNonIndexedVerts);

    std::vector<VertexTex> texVerts;
    std::vector<uint32_t> texIndices;
    Torus::generateIndexedTextured(RADIAL_RES, TUBULAR_RES, MAJOR_RADIUS, MINOR_RADIUS, texVerts, texIndices);

    MeshGL wireMesh = uploadRGBMeshIndexed(rgbIndexedVerts, rgbIndices);
    MeshGL gouraudNonIndexedMesh = uploadRGBMeshNonIndexed(rgbNonIndexedVerts);
    MeshGL gouraudIndexedMesh = uploadRGBMeshIndexed(rgbIndexedVerts, rgbIndices);
    MeshGL texturedMesh = uploadTexturedMeshIndexed(texVerts, texIndices);

    GLuint textureID = loadWebPTexture("texture.webp");
    if (textureID == 0) {
        std::cerr << "texture.webp not found or could not be decoded. Using procedural checkerboard fallback.\n";
        textureID = createFallbackCheckerTexture();
    }

    std::cout << "Controls:\n"
              << "  1 = wireframe\n"
              << "  2 = gouraud/vertex-color non-indexed\n"
              << "  3 = gouraud/vertex-color indexed\n"
              << "  4 = textured indexed\n"
              << "  SPACE = pause rotation\n"
              << "  ESC = quit\n\n"
              << "Mesh statistics:\n"
              << "  Non-indexed color vertices submitted: " << rgbNonIndexedVerts.size() << '\n'
              << "  Indexed unique color vertices:       " << rgbIndexedVerts.size() << '\n'
              << "  Indexed elements submitted:           " << rgbIndices.size() << '\n'
              << "  Triangles:                            " << (rgbIndices.size() / 3u) << "\n\n";

    RenderMode mode = RenderMode::Wireframe;
    bool animate = true;
    bool lastSpace = false;
    float angle = 0.0f;

    while (!glfwWindowShouldClose(win)) {
        glfwPollEvents();

        if (glfwGetKey(win, GLFW_KEY_1) == GLFW_PRESS) mode = RenderMode::Wireframe;
        if (glfwGetKey(win, GLFW_KEY_2) == GLFW_PRESS) mode = RenderMode::GouraudNonIndexed;
        if (glfwGetKey(win, GLFW_KEY_3) == GLFW_PRESS) mode = RenderMode::GouraudIndexed;
        if (glfwGetKey(win, GLFW_KEY_4) == GLFW_PRESS) mode = RenderMode::TexturedIndexed;

        const bool spaceNow = glfwGetKey(win, GLFW_KEY_SPACE) == GLFW_PRESS;
        if (spaceNow && !lastSpace) {
            animate = !animate;
        }
        lastSpace = spaceNow;

        if (animate) {
            angle += 0.0125f;
        }

        int width = 1, height = 1;
        glfwGetFramebufferSize(win, &width, &height);
        const float aspect = static_cast<float>(width) / static_cast<float>(height > 0 ? height : 1);

        const glm::mat4 proj = glm::perspective(glm::radians(45.0f), aspect, 0.1f, 100.0f);
        const glm::mat4 view = glm::lookAt(glm::vec3(0.0f, 0.1f, 2.9f), glm::vec3(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        glm::mat4 model(1.0f);
        model = glm::rotate(model, angle, glm::vec3(0.3f, 1.0f, 0.2f));
        model = glm::rotate(model, 0.45f * angle, glm::vec3(1.0f, 0.0f, 0.0f));
        const glm::mat4 viewProj = proj * view;

        glClearColor(0.06f, 0.07f, 0.11f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        if (mode == RenderMode::Wireframe || mode == RenderMode::GouraudNonIndexed || mode == RenderMode::GouraudIndexed) {
            glUseProgram(gouraudProg);
            setCommonUniforms(gouraudProg, model, viewProj);

            if (mode == RenderMode::Wireframe) {
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
                drawMesh(wireMesh);
                updateWindowTitle(win, modeName(mode), rgbIndexedVerts.size(), rgbIndices.size(), rgbIndices.size() / 3u);
            } else if (mode == RenderMode::GouraudNonIndexed) {
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
                drawMesh(gouraudNonIndexedMesh);
                updateWindowTitle(win, modeName(mode), rgbIndexedVerts.size(), rgbNonIndexedVerts.size(), rgbNonIndexedVerts.size() / 3u);
            } else {
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
                drawMesh(gouraudIndexedMesh);
                updateWindowTitle(win, modeName(mode), rgbIndexedVerts.size(), rgbIndices.size(), rgbIndices.size() / 3u);
            }
        } else {
            glUseProgram(textureProg);
            setCommonUniforms(textureProg, model, viewProj);
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, textureID);
            glUniform1i(glGetUniformLocation(textureProg, "tex"), 0);
            drawMesh(texturedMesh);
            updateWindowTitle(win, modeName(mode), texVerts.size(), texIndices.size(), texIndices.size() / 3u);
        }

        glfwSwapBuffers(win);

        if (glfwGetKey(win, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
            glfwSetWindowShouldClose(win, GLFW_TRUE);
        }
    }

    glDeleteTextures(1, &textureID);
    wireMesh.destroy();
    gouraudNonIndexedMesh.destroy();
    gouraudIndexedMesh.destroy();
    texturedMesh.destroy();
    glDeleteProgram(gouraudProg);
    glDeleteProgram(textureProg);
}
