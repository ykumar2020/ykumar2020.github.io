#include "common.hh"

#include <webp/decode.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <stdexcept>

GLFWwindow* win = nullptr;

namespace {
void framebuffer_size_callback(GLFWwindow*, int width, int height) {
    glViewport(0, 0, width, height);
}

std::string readFile(const char* path) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) {
        throw std::runtime_error(std::string("Failed to open file: ") + path);
    }
    std::ostringstream ss;
    ss << stream.rdbuf();
    return ss.str();
}

void check_status(GLuint obj, bool isShader) {
    GLint status = GL_FALSE;
    GLchar log[4096] = {};
    if (isShader) {
        glGetShaderiv(obj, GL_COMPILE_STATUS, &status);
    } else {
        glGetProgramiv(obj, GL_LINK_STATUS, &status);
    }

    if (status == GL_TRUE) return;

    if (isShader) {
        glGetShaderInfoLog(obj, static_cast<GLsizei>(sizeof(log)), nullptr, log);
        throw std::runtime_error(std::string("Shader compilation failed:\n") + log);
    } else {
        glGetProgramInfoLog(obj, static_cast<GLsizei>(sizeof(log)), nullptr, log);
        throw std::runtime_error(std::string("Program link failed:\n") + log);
    }
}

void attach_shader(GLuint program, GLenum type, const char* src) {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &src, nullptr);
    glCompileShader(shader);
    check_status(shader, true);
    glAttachShader(program, shader);
    glDeleteShader(shader);
}
} // namespace

GLuint build_prog(const char vertex_shader[], const char fragment_shader[]) {
    GLuint prog = glCreateProgram();
    attach_shader(prog, GL_VERTEX_SHADER, vertex_shader);
    attach_shader(prog, GL_FRAGMENT_SHADER, fragment_shader);
    glLinkProgram(prog);
    check_status(prog, false);
    return prog;
}

GLuint loadShaders(const char vertexPath[], const char fragmentPath[]) {
    const std::string vCode = readFile(vertexPath);
    const std::string fCode = readFile(fragmentPath);
    return build_prog(vCode.c_str(), fCode.c_str());
}

GLFWwindow* createWindow(uint32_t w, uint32_t h, const char title[]) {
    if (!glfwInit()) {
        throw std::runtime_error("glfwInit failed");
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    win = glfwCreateWindow(static_cast<int>(w), static_cast<int>(h), title, nullptr, nullptr);
    if (!win) {
        glfwTerminate();
        throw std::runtime_error("Failed to create GLFW window");
    }

    glfwMakeContextCurrent(win);
    glfwSetFramebufferSizeCallback(win, framebuffer_size_callback);
    glfwSwapInterval(1);

    glewExperimental = GL_TRUE;
    const GLenum glewErr = glewInit();
    if (glewErr != GLEW_OK) {
        glfwDestroyWindow(win);
        glfwTerminate();
        throw std::runtime_error(reinterpret_cast<const char*>(glewGetErrorString(glewErr)));
    }

    int fbw = 0, fbh = 0;
    glfwGetFramebufferSize(win, &fbw, &fbh);
    glViewport(0, 0, fbw, fbh);
    return win;
}

GLuint loadWebPTexture(const char* filePath) {
    std::ifstream file(filePath, std::ios::binary | std::ios::ate);
    if (!file) {
        return 0;
    }

    const std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    std::vector<uint8_t> buffer(static_cast<std::size_t>(size));
    if (!file.read(reinterpret_cast<char*>(buffer.data()), size)) {
        return 0;
    }

    int w = 0, h = 0;
    uint8_t* data = WebPDecodeRGBA(buffer.data(), static_cast<size_t>(size), &w, &h);
    if (!data) {
        return 0;
    }

    GLuint tex = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    WebPFree(data);
    return tex;
}

GLuint createFallbackCheckerTexture(int size) {
    std::vector<unsigned char> img(static_cast<std::size_t>(size * size * 4));
    for (int y = 0; y < size; ++y) {
        for (int x = 0; x < size; ++x) {
            const bool checker = ((x / 32) + (y / 32)) % 2 == 0;
            const unsigned char r = checker ? 245 : 45;
            const unsigned char g = checker ? 120 : 30;
            const unsigned char b = checker ? 255 : 180;
            const std::size_t idx = static_cast<std::size_t>((y * size + x) * 4);
            img[idx + 0] = r;
            img[idx + 1] = g;
            img[idx + 2] = b;
            img[idx + 3] = 255;
        }
    }

    GLuint tex = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, size, size, 0, GL_RGBA, GL_UNSIGNED_BYTE, img.data());
    glGenerateMipmap(GL_TEXTURE_2D);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    return tex;
}

void updateWindowTitle(GLFWwindow* window, const std::string& modeText, std::size_t uniqueVerts,
                       std::size_t drawVertices, std::size_t triangles) {
    const std::string title =
        "Torus Demo | " + modeText +
        " | unique verts=" + std::to_string(uniqueVerts) +
        " | submitted verts=" + std::to_string(drawVertices) +
        " | triangles=" + std::to_string(triangles);
    glfwSetWindowTitle(window, title.c_str());
}

int main() {
    try {
        glmain();
        if (win) {
            glfwDestroyWindow(win);
            win = nullptr;
        }
        glfwTerminate();
        return 0;
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        if (win) {
            glfwDestroyWindow(win);
            win = nullptr;
        }
        glfwTerminate();
        return -1;
    }
}
