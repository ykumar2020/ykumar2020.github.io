#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <iostream>

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/ext.hpp>

extern GLFWwindow* win;

GLFWwindow* createWindow(uint32_t w, uint32_t h, const char title[]);
GLuint loadShaders(const char vertexPath[], const char fragmentPath[]);
GLuint build_prog(const char vertex_shader[], const char fragment_shader[]);
GLuint loadWebPTexture(const char* filePath);
GLuint createFallbackCheckerTexture(int size = 256);

void updateWindowTitle(GLFWwindow* window, const std::string& modeText, std::size_t uniqueVerts,
                       std::size_t drawVertices, std::size_t triangles);

void glmain();
