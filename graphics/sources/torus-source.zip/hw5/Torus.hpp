#pragma once

#include <cstdint>
#include <vector>

struct VertexRGB {
    float x, y, z;
    float r, g, b;
};

struct VertexTex {
    float x, y, z;
    float u, v;
};

class Torus {
public:
    static void generateIndexedRGB(uint32_t radialRes, uint32_t tubularRes, float majorRadius, float minorRadius,
                                   std::vector<VertexRGB>& vertices, std::vector<uint32_t>& indices);

    static void generateNonIndexedRGB(uint32_t radialRes, uint32_t tubularRes, float majorRadius, float minorRadius,
                                      std::vector<VertexRGB>& vertices);

    static void generateIndexedTextured(uint32_t radialRes, uint32_t tubularRes, float majorRadius, float minorRadius,
                                        std::vector<VertexTex>& vertices, std::vector<uint32_t>& indices);
};
