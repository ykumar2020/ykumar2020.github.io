#include "common/common.hh"
#include <vector>
#include <cmath>
#include <iostream>

// Use a hardcoded PI to avoid MPI/M_PI errors on Windows
#define PI 3.14159265358979323846f

struct Vertex {
    float x, y, z;
    float r, g, b;
    float u, v;
};

void generateTorus(uint32_t radialRes, uint32_t tubularRes, float R, float r, 
                   std::vector<Vertex>& vertices, std::vector<uint32_t>& indices) {
    for (uint32_t i = 0; i <= radialRes; i++) {
        float u_angle = (float)i / radialRes * 2.0f * PI;
        for (uint32_t j = 0; j <= tubularRes; j++) {
            float v_angle = (float)j / tubularRes * 2.0f * PI;
            float x = (R + r * cos(v_angle)) * cos(u_angle);
            float y = (R + r * cos(v_angle)) * sin(u_angle);
            float z = r * sin(v_angle);

            // Gouraud Colors
            float pr = (cos(u_angle) + 1.0f) * 0.5f;
            float pg = (sin(v_angle) + 1.0f) * 0.5f;
            
            vertices.push_back({x, y, z, pr, pg, 1.0f - pr, (float)i/radialRes, (float)j/tubularRes});
        }
    }

    for (uint32_t i = 0; i < radialRes; i++) {
        for (uint32_t j = 0; j < tubularRes; j++) {
            uint32_t first = i * (tubularRes + 1) + j;
            uint32_t second = first + tubularRes + 1;
            // Task 3: Indexed triangles
            indices.push_back(first); indices.push_back(second); indices.push_back(first + 1);
            indices.push_back(second); indices.push_back(second + 1); indices.push_back(first + 1);
        }
    }
}

void glmain() {
    win = createWindow(1000, 800, "Torus Demo");
    glEnable(GL_DEPTH_TEST);

    // Using your existing shaders from the upload
    uint32_t prog = loadShaders("04transform.vert", "03gouraud.frag");
    
    std::vector<Vertex> verts;
    std::vector<uint32_t> indices;
    generateTorus(50, 30, 0.6f, 0.2f, verts, indices);

    uint32_t vao, vbo, ebo;
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glGenBuffers(1, &ebo);

    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(Vertex), verts.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(uint32_t), indices.data(), GL_STATIC_DRAW);

    // Attributes for 04transform.vert: pos(0), color(1)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    uint32_t matrixID = glGetUniformLocation(prog, "transform");
    float angle = 0;

    while (!glfwWindowShouldClose(win)) {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glUseProgram(prog);

        glm::mat4 mvp = glm::perspective(glm::radians(45.0f), 1.25f, 0.1f, 10.0f) * glm::translate(glm::mat4(1.0f), glm::vec3(0,0,-3)) *
                        glm::rotate(glm::mat4(1.0f), angle, glm::vec3(0, 1, 0.5));
        glUniformMatrix4fv(matrixID, 1, GL_FALSE, &mvp[0][0]);

        // Toggle Wireframe with Key 1, Solid with Key 2
        if (glfwGetKey(win, GLFW_KEY_1) == GLFW_PRESS) glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        if (glfwGetKey(win, GLFW_KEY_2) == GLFW_PRESS) glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

        glDrawElements(GL_TRIANGLES, (GLsizei)indices.size(), GL_UNSIGNED_INT, 0);

        angle += 0.01f;
        glfwSwapBuffers(win);
        glfwPollEvents();
    }
}