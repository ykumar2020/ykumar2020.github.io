#version 330 core
layout(location = 0) in vec3 pos;
layout(location = 1) in vec3 color;

uniform mat4 uModel;
uniform mat4 uViewProj;
uniform mat3 uNormalMatrix;
uniform float uMajorRadius;
uniform vec3 uLightDirWorld;

out vec3 vColor;

vec3 torusNormalObject(vec3 p, float majorRadius) {
    vec2 xy = p.xy;
    float lenXY = max(length(xy), 1e-6);
    vec3 tubeCenter = vec3((xy / lenXY) * majorRadius, 0.0);
    return normalize(p - tubeCenter);
}

void main() {
    vec3 nObj = torusNormalObject(pos, uMajorRadius);
    vec3 nWorld = normalize(uNormalMatrix * nObj);

    float ndotl = max(dot(nWorld, normalize(-uLightDirWorld)), 0.0);
    float ambient = 0.25;
    float diffuse = 0.75 * ndotl;

    vColor = color * (ambient + diffuse);

    gl_Position = uViewProj * uModel * vec4(pos, 1.0);
}
