# Nova: virtual teaching assistant starter

A working classroom prototype by Julie Kumar. This public package contains three starter slides, application source, and unit checks. It excludes private teaching decks, credentials, local settings, and recordings.

Install Node.js 22.16+ and Python 3.11+. In this folder run:

```
npm ci
python -m pip install pymupdf
npm run build
```

Copy `.env.example` to `.env` and set your own `OPENAI_API_KEY`. Then run `npm start` and open http://localhost:4317 in Chrome or Edge. Live voice uses your project's paid OpenAI API access. Rehearsal can read notes without connecting.

Upload a PDF. On Windows with PowerPoint installed, install `pywin32` to import PPTX directly and retrieve speaker notes. On Mac, export to PDF first. Native slide animations and video are flattened on import.

Click Connect live audio and allow the microphone. Inform the class that audio is processed by OpenAI. Choose a handoff limit, then say 'Nova, continue my lecture.' Say 'Nova, stop' or press Esc to take back the floor. Typed questions and buttons are also supported. Anyone near the microphone can use the wake phrase. Disconnect releases the microphone.

The assistant uses the current slide image, extracted text, notes, and bounded recent transcript. It can make mistakes: review its explanations. Edit notes and export them before closing the tab. Imported files remain locally in public/lectures; the transcript is not saved by the app.

This is a browser lecture player, not a desktop PowerPoint overlay. Its 3D robot is procedurally animated, with amplitude-driven mouth movement. It is not a photorealistic or phoneme-accurate avatar.

Run `npm test` for the seven speech-permission and command checks. Real WebRTC and generated-audio wake/stop checks passed in the development environment. Actual classroom acoustics and long sessions remain unvalidated. See https://ykumar2020.github.io/labs/nova/guide.html for setup, capabilities, and boundaries.

The server binds to localhost. Do not publish an API key or expose this local prototype as a public voice service without appropriate authentication and usage controls.
