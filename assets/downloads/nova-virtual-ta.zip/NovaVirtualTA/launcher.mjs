import {readFile} from 'node:fs/promises';import {fileURLToPath} from 'node:url';import path from 'node:path';
import {spawn} from 'node:child_process';
const root=path.dirname(fileURLToPath(import.meta.url));process.chdir(root);
// This workstation can reference an existing key file without copying its secrets.
if(!process.env.OPENAI_API_KEY){try{const settings=JSON.parse(await readFile('local-settings.json','utf8'));const source=await readFile(settings.keyFile,'utf8');const line=source.split(/\r?\n/).find(x=>x.startsWith('OPENAI_API_KEY='));if(line)process.env.OPENAI_API_KEY=line.slice(line.indexOf('=')+1).trim().replace(/^['"]|['"]$/g,'');}catch{}}
const url=`http://localhost:${process.env.PORT||4317}`;
function open(){if(process.env.OPEN_BROWSER!=='1')return;const executable=process.platform==='win32'?'explorer.exe':process.platform==='darwin'?'open':'xdg-open';spawn(executable,[url],{detached:true,stdio:'ignore',windowsHide:true}).unref();}
let running=false;try{running=(await fetch(url+'/api/health',{signal:AbortSignal.timeout(1000)}).then(r=>r.json())).local===true;}catch{}
if(running){console.log('Nova is already running: '+url);open();}else{const {server}=await import('./server.mjs');if(server.listening)open();else server.once('listening',open);}
