// This is the speech permission boundary. The model never grants itself the floor.
export function addressedCommand(text) {
  const t=String(text).trim().toLowerCase().replace(/[.,!?]/g,'');
  const m=t.match(/^(?:hey\s+|okay\s+|ok\s+)?(?:nova|hey nova|teaching assistant)\b\s*(.*)$/);
  if(!m)return null;
  const q=m[1].replace(/^(?:(?:please|can you|could you|would you)\s+)+/,'');
  if(/^(?:stop|pause|quiet|that's enough|that is enough|i'm back|i am back|take a break)\b/.test(q))return {type:'stop'};
  if(/^(?:continue(?: my| the)? lecture|take over|present|continue teaching|carry on)\b/.test(q))return {type:'present'};
  if(/^(?:next slide)\b/.test(q))return {type:'next'};
  if(/^(?:previous slide|go back)\b/.test(q))return {type:'previous'};
  return q ? {type:'question',text:q} : null;
}
export class Floor {
  constructor(){this.epoch=0;this.mode='idle';this.pending=null;this.responseId=null;}
  grant(mode){this.epoch++;this.mode=mode;this.pending=null;this.responseId=null;return this.epoch;}
  request(){if(this.mode==='idle'||this.pending||this.responseId)return null;this.pending=`${this.epoch}:${Date.now()}`;return this.pending;}
  accept(response){if(this.mode==='idle'||!this.pending||response.metadata?.permission!==this.pending)return false;this.responseId=response.id;this.pending=null;return true;}
  revoke(){const id=this.responseId;this.epoch++;this.mode='idle';this.pending=null;this.responseId=null;return id;}
  finish(id){if(id!==this.responseId)return false;this.responseId=null;return true;}
}
