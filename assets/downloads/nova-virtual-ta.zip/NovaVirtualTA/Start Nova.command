#!/bin/bash
cd "$(dirname "$0")"
OPEN_BROWSER=1 node --env-file-if-exists=.env launcher.mjs
