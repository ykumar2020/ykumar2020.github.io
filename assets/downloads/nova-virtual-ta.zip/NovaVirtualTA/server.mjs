import express from 'express';
import multer from 'multer';
import {mkdir,readFile,rm} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {spawn} from 'node:child_process';
import {sessionConfig} from './session.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const app=express(),port=Number(process.env.PORT||4317);
await mkdir(path.join(root,'uploads'),{recursive:true});
await mkdir(path.join(root,'public','lectures'),{recursive:true});
const origins=new Set([`http://localhost:${port}`,`http://127.0.0.1:${port}`]);
app.use((req,res,next)=>{res.set({'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'no-store'});if(!['localhost','127.0.0.1'].includes(req.hostname))return res.status(403).json({error:'Local access only.'});if(req.method==='POST'&&!origins.has(req.headers.origin))return res.status(403).json({error:'Local app origin required.'});next();});
app.get('/api/health',(_req,res)=>res.json({ready:Boolean(process.env.OPENAI_API_KEY),model:sessionConfig().model,local:true}));
let creating=false,lastSession=0;
app.post('/api/session',express.text({type:'application/sdp',limit:'128kb'}),async(req,res)=>{
 if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'Set OPENAI_API_KEY on the local server, then restart. Rehearsal still works.'});
 if(typeof req.body!=='string'||!req.body.startsWith('v=0'))return res.status(400).json({error:'A valid browser SDP offer is required.'});
 if(creating||Date.now()-lastSession<3000)return res.status(429).json({error:'Please wait before reconnecting.'});
 creating=true;lastSession=Date.now();
 try{const form=new FormData();form.set('sdp',req.body);form.set('session',JSON.stringify(sessionConfig()));const r=await fetch('https://api.openai.com/v1/realtime/calls',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},body:form,signal:AbortSignal.timeout(30000)});const body=await r.text();if(!r.ok){let message='Live audio session failed.';try{message=JSON.parse(body).error?.message||message;}catch{}return res.status(r.status).json({error:message});}res.type('application/sdp').send(body);}catch(e){res.status(502).json({error:'Could not connect to live audio. Check the server connection and try again.'});}finally{creating=false;}
});
const upload=multer({dest:path.join(root,'uploads'),limits:{fileSize:40*1024*1024,files:1}});
app.post('/api/lecture',upload.single('lecture'),async(req,res)=>{
 const f=req.file;if(!f)return res.status(400).json({error:'Choose a PDF or PPTX file.'});
 const ext=path.extname(f.originalname).toLowerCase();if(!['.pdf','.pptx'].includes(ext)){await rm(f.path,{force:true});return res.status(400).json({error:'Use PDF or PPTX.'});}
 const id=randomUUID();const out=path.join(root,'public','lectures',id);
 try {await new Promise((resolve,reject)=>{const p=spawn(process.env.PYTHON||'python',[path.join(root,'tools','import_lecture.py'),f.path,out,ext],{windowsHide:true});let error='';p.stderr.on('data',d=>error+=d.toString().slice(0,2000));const timer=setTimeout(()=>{p.kill();reject(new Error('Slide import timed out. Try a PDF export.'));},180000);p.on('error',reject);p.on('close',code=>{clearTimeout(timer);code===0?resolve():reject(new Error(error||'Slide import failed. Try a PDF export.'));});});res.json({url:`/lectures/${id}/lecture.json`});}catch(e){res.status(422).json({error:e.message});}finally{await rm(f.path,{force:true});}
});
app.use(express.static(path.join(root,'public'),{dotfiles:'deny'}));
app.use((err,req,res,next)=>res.status(400).json({error:err.code==='LIMIT_FILE_SIZE'?'File limit: 40 MB.': 'Upload could not be processed.'}));
export const server=app.listen(port,'127.0.0.1',()=>console.log(`Nova is ready: http://localhost:${port}`));
