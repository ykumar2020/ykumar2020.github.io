"""Local-only slide rendering. Original files are opened read-only; no macros are run."""
import sys, json, re, zipfile, shutil
from pathlib import Path
import xml.etree.ElementTree as ET
import fitz

def slide_title(text, index):
    candidates=[x.strip() for x in text.splitlines() if x.strip() and not re.match(r'^(CPS\s*\d|\d+$|Source template:|(?:Yulia|Julie) Kumar)',x.strip(),re.I)]
    return (candidates or [f'Slide {index+1}'])[0][:160]

def import_lecture(source, target, extension, notes_source=None):
    source=Path(source).resolve(); target=Path(target).resolve(); target.mkdir(parents=True,exist_ok=True)
    notes=[]; texts=[]; warning=''; pdf=source
    ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
    if extension=='.pptx' or notes_source:
        with zipfile.ZipFile(notes_source or source) as z:
            # Bound decompression before parsing user-provided OOXML.
            if sum(i.file_size for i in z.infolist())>400_000_000: raise ValueError('PPTX is too large after decompression.')
            slides=sorted([n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+.xml',n)],key=lambda n:int(re.search(r'(\d+)\.xml',n)[1]))
            for name in slides:
                texts.append('\n'.join(e.text or '' for e in ET.fromstring(z.read(name)).findall('.//a:t',ns)))
                note=''; rel=name.replace('slides/','slides/_rels/')+'.rels'
                if rel in z.namelist():
                    for r in ET.fromstring(z.read(rel)):
                        if r.attrib.get('Type','').endswith('/notesSlide'):
                            p='ppt/notesSlides/'+r.attrib['Target'].split('/')[-1]
                            if p in z.namelist(): note='\n'.join(e.text or '' for e in ET.fromstring(z.read(p)).findall('.//a:t',ns))
                notes.append('\n'.join(x for x in note.splitlines() if x.strip() and not x.strip().startswith('Source template:') and not x.strip().isdigit()))
    if extension=='.pptx':
        local=target/'source.pptx'; shutil.copyfile(source,local); pdf=target/'slides.pdf'
        try:
            import win32com.client, pythoncom
            pythoncom.CoInitialize(); app=win32com.client.DispatchEx('PowerPoint.Application')
            # Force-disable Office macros; PPTX cannot contain VBA by design.
            app.AutomationSecurity=3
            deck=app.Presentations.Open(str(local),ReadOnly=True,Untitled=False,WithWindow=False)
            try: deck.SaveAs(str(pdf),32)
            finally: deck.Close()
            # Do not Quit: Office may share the user's running application instance.
        except Exception:
            warning='PowerPoint rendering unavailable. Text-only slide view; export your deck to PDF for exact visuals.'
        finally:
            local.unlink(missing_ok=True)
    result=[]
    if pdf.exists() and (extension=='.pdf' or pdf.suffix=='.pdf'):
        with fitz.open(pdf) as doc:
            if len(doc)>250: raise ValueError('Maximum 250 slides per lecture.')
            for i,page in enumerate(doc):
                image=f'slide-{i+1:03}.png'; page.get_pixmap(matrix=fitz.Matrix(min(1.6,1600/page.rect.width),min(1.6,1600/page.rect.width)),alpha=False).save(target/image)
                text=page.get_text().strip()
                result.append({'title':slide_title(text,i),'text':text,'notes':notes[i] if i<len(notes) else '', 'image':image})
    else:
        result=[{'title':slide_title(t,i),'text':t,'notes':notes[i]} for i,t in enumerate(texts)]
    if not result: raise ValueError('No readable slides were found.')
    data={'title':source.stem if len(source.stem)<80 else 'Imported lecture','slides':result,'warning':warning,'notesSource':'PowerPoint notes' if notes else 'No notes imported; add instructor notes in the player.'}
    (target/'lecture.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    return data
if __name__=='__main__': import_lecture(*sys.argv[1:])
