@echo off
cd /d "%~dp0"
set OPEN_BROWSER=1
node --env-file-if-exists=.env launcher.mjs
pause
